import json
import uuid
from datetime import datetime
import random

age_groups = ["13-15", "16-18"]
regions = ["Europe", "Asia", "North America", "South America", "Africa"]
emotions = ["sadness", "joy", "loneliness", "stress", "hope", "anxiety", "curiosity", "anger"]

def generate_sample_entry():
    return {
        "interaction_id": str(uuid.uuid4()),
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "age_group": random.choice(age_groups),
        "region": random.choice(regions),
        "sentiment_score": round(random.uniform(-1.0, 1.0), 2),
        "emotion_tags": random.sample(emotions, k=random.randint(1, 3)),
        "trigger_event": random.choice(["crisis_alert", "trust_signal", "follow_up", None]),
        "consent_level": random.randint(1, 5),
        "alert_flag": random.choice([True, False]),
        "anonymized_text": "This is a placeholder anonymized conversation text."
    }

def generate_dataset(n=10):
    return [generate_sample_entry() for _ in range(n)]

if __name__ == "__main__":
    dataset = generate_dataset(10)
    with open("sample_dataset.json", "w") as f:
        json.dump(dataset, f, indent=4)
    print("✅ 10 sample entries saved to sample_dataset.json")
