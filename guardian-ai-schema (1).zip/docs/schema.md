# Guardian AI Schema – Specification

This document describes the data schema used to log, tag, and analyze AI–teen interactions.

...

## 🔄 Versioning

This is **Schema v0.1.0**  
Expect future updates with risk weighting, long-term trend tracking, and trust graph metrics.
