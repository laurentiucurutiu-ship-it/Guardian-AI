# Contributing to Guardian AI Schema 🛡️

Thanks for your interest in contributing! We welcome collaboration on building safer, emotionally intelligent AI systems for teens.

## 🛠️ Getting Started

1. **Fork the Repository**
2. **Clone Your Fork**
   ```bash
   git clone https://github.com/your-username/guardian-ai-schema.git
   cd guardian-ai-schema
   ```
3. **Install Dependencies**
   - Python 3.8+ required
   - No external libraries yet required

4. **Generate Sample Dataset**
   ```bash
   cd scripts
   python generate_sample.py
   ```

## 🔃 Working on Changes

- Create a feature branch:
  ```bash
  git checkout -b feature/my-new-feature
  ```
- Make your changes and commit:
  ```bash
  git add .
  git commit -m "Add new feature: ..."
  ```
- Push to your fork and submit a Pull Request.

## ✅ Code Guidelines

- Keep code clean and well-documented.
- Use clear function names.
- Comment critical logic or data processing steps.

## 📫 Need Help?

- Open an Issue.
- Or reach us via email: guardian-ai@protonmail.com (example)
